<?php
// implementation of add function
function add($int1, $int2) {
	return $int1 + $int2;
}
function mult($int1, $int2) {
	return $int1 * $int2;
}
?>