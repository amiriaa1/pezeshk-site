vti_encoding:SR|utf8-nl
vti_timelastmodified:TW|25 Jun 2008 04:33:08 -0000
vti_author:SR|SIC\\khrafati
vti_modifiedby:SR|SIC\\khrafati
vti_nexttolasttimemodified:TW|25 Jun 2008 04:33:08 -0000
vti_timecreated:TR|15 Jul 2008 06:39:44 -0000
vti_cacheddtm:TX|15 Jul 2008 06:39:44 -0000
vti_filesize:IR|38507
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_charset:SR|windows-1252
vti_extenderversion:SR|6.0.2.5516
vti_backlinkinfo:VX|
vti_syncwith_www.rafati.ir\:80:TW|25 Jun 2008 04:33:08 -0000
