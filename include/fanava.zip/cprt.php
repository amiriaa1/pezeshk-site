<?php
define('_CPRT', '
	<hr>
	<div style="text-align:center; direction:ltr; font-size:8pt;">
		Powered by <a href="http://nomra.ir" target="_blank">Nomra '._NOMRA_V.'</a> : Learning Management System
	</div>'
	);
define('_CPRT_FULL', '
	<hr>
	<div style="text-align:center; direction:ltr; font-size:8pt;">
		Powered by <a href="http://nomra.ir" target="_blank">Nomra '._NOMRA_V.'</a> : Learning Management System
		<br>Designed by <a href="http://niroomand.ir" target="_blank">Hamid Reza Niroomand</a>
		<br>at <a href="http://aftab.cc" target="_blank">Aftab.cc</a>
	</div>'
	);

?>
